<?php
header('location: ../');
?>